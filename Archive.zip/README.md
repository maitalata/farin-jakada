# Farin Jakada

## Farin Jakada Main System.

Farin Jakada is a system developed by the IT Firm IWORLDOFTECH for providing Islamic Educational resources for the general public. The System is provided to the general public free of charge.

----------------------------------------------------------------------------------------------------

The System is developed using Codeigniter 4 and is licensed under the open source permisive MIT License.
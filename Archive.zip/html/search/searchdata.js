var indexSectionsWithContent =
{
  0: "abcdefghiklmpstuv",
  1: "abcdefghiklmpstuv",
  2: "a",
  3: "cgil",
  4: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Functions",
  4: "Pages"
};


var searchData=
[
  ['database_0',['Database',['../class_config_1_1_database.html',1,'Config']]],
  ['doctypes_1',['DocTypes',['../class_config_1_1_doc_types.html',1,'Config']]]
];

var searchData=
[
  ['useragents_0',['UserAgents',['../class_config_1_1_user_agents.html',1,'Config']]]
];

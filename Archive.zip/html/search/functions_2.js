var searchData=
[
  ['index_0',['index',['../class_app_1_1_controllers_1_1_admin.html#a149eb92716c1084a935e04a8d95f7347',1,'App\Controllers\Admin\index()'],['../class_app_1_1_controllers_1_1_home.html#a149eb92716c1084a935e04a8d95f7347',1,'App\Controllers\Home\index()']]],
  ['initcontroller_1',['initController',['../class_app_1_1_controllers_1_1_base_controller.html#aaa4ae087c2582ea613c7255f73d8a623',1,'App::Controllers::BaseController']]]
];

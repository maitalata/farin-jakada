var searchData=
[
  ['basecontroller_0',['BaseController',['../class_app_1_1_controllers_1_1_base_controller.html',1,'App::Controllers']]]
];

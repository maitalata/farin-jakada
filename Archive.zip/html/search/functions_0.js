var searchData=
[
  ['checklogin_0',['checkLogin',['../class_app_1_1_models_1_1_admin_model.html#a1e3ed66c22af7cd6f6039888369a7dca',1,'App::Models::AdminModel']]]
];

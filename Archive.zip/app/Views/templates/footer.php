	<!---->
	<div class="footer">
		<div class="container">
			<p>Copyrights © 2015 Blog All rights reserved | Template by <a href="http://w3layouts.com/">W3layouts</a></p>
		</div>
	</div>
</body>

</html>